var myrules = {
// rules for name functions
	'.eInput' : function(el){
		el.onfocus = function(){ highLight(this, true); checkErr(this); return false; };
		el.onkeyup = function(){ checkErr(this); return false; };
		el.onblur = function(){ highLight(this, false); checkErr(this); return false; }
	},
	'#contact' : function(el){
		el.onclick = function(){ setContact(this); return true; }
	},
	'#okDone' : function(el){
		el.onclick = function(){ reserve(); return false; }
	},
	'#okUpdate' : function(el){
		el.onclick = function(){ update(); return false; }
	},
	'#pwGo' : function(el){
		el.onclick = function(){ goView(this.previousSibling); return false; }
	},
	'#refresh' : function(el){
		el.onclick = function(){ goRefresh(); return false; }
	},
	'#pw' : function(el){
		el.onkeydown = function(event){ 
      var key = window.event?window.event.keyCode:event.which; if(key==13) goView(this); return true; };
	},
	'.heading' : function(el){
		el.onclick = function(event){ goSort(this); return false; };
		el.onmouseover = function(event){ this.style.color="#093"; return false; };
		el.onmouseout = function(event){ this.style.color=""; return false; };
	}
	
};

Behaviour.register(myrules);
