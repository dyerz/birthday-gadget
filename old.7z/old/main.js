var xmlHttp;

function addLoadEvent(func) {
  var oldonload = window.onload;
  if (typeof window.onload != 'function') { window.onload = func; }
  else { window.onload = function() { if (oldonload) {  oldonload(); } func();}}}

addLoadEvent(setMyFocus);
 
function setMyFocus(){ var myObj;
  if(myObj=document.getElementById("name")) {myObj.focus(); return;}
  if(myObj=document.getElementById("pw")) {myObj.focus(); return;} }

function highLight(obj, dir){
  var titleObj=obj.parentNode.previousSibling;
  if(titleObj.nodeType===3) titleObj=titleObj.previousSibling;
  titleObj.style.color=(dir)?"#F60":"";}

function checkName(value){
  var filter=/^\w+ \w+$/; var valid=filter.test(value);
  return(Array(valid, valid?"OK":"* Please use the format: FirstName LastName"));}

function checkEmail(value){
  var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/; var valid=filter.test(value);
  if(!valid) return(Array(valid, valid?"OK":"* Please enter a valid email address"));
  checkDB("email", value); return(Array(false, "* Checking email address..."));}

function checkPhone(value){
  var filter=/^1?[\-\. ]?\(?\d{3}\)?[\-\. ]?\d{3}[\-\)\. ]?\d{4}$/; var valid=filter.test(value);
	if(!valid) return(Array(valid, valid?"OK":"* Please enter a valid phone number"));
  checkDB("phone", value); return(Array(false, "* Checking phone number..."));}

function checkDB(mode, value){
  working();
  var url=handleUrl("mode", "test", "type", mode, "value", value);
  handleXmlRequest("test", url)}

function checkNum(value){
  var filter=/^\d+$/; var valid=filter.test(value);
  if(!valid) return(Array(valid, valid?"OK":"* Please type in a number 1-20"));
  var intValue=parseInt(value, 10);
  if(intValue<=0) return(Array(false, "* You should reserve at least 1 ticket."));
  if(intValue>20) return(Array(false, "* To Reserve More than 20 Tickets, please call 937.372.5887"));
  return(Array(true, "OK"));}

function checkReady(){
  var chex=new Array("name", "email", "phone", "num");
  for(var i=0; i<chex.length; i++){
    var tempObj=document.getElementById(chex[i]).parentNode.nextSibling;
    if(tempObj.nodeType==3) tempObj=tempObj.nextSibling;
    if(tempObj.innerHTML!="OK") return(false);}
  if(document.getElementById("check").value!="") return false;
  return(true);}

function checkErr(obj){
  if(obj.value=="") return;
  var errObj=obj.parentNode.nextSibling;
  if(errObj.nodeType===3) errObj=errObj.nextSibling;
  var test;
  switch(obj.id){
    case "name": test=checkName(obj.value); break;
    case "phone": test=checkPhone(obj.value); break;
    case "email": test=checkEmail(obj.value); break;
    case "num": test=checkNum(obj.value); break;
    default: test=new Array(false, "Something Went Wrong!");}
  var buttonObj=document.getElementById("okDone") || document.getElementById("okUpdate");
  errObj.style.color=(test[0]?"#093":"#D00"); errObj.innerHTML=test[1];
  buttonObj.disabled=!checkReady();}
  
function reserve(){
  working();
  var nameObj=document.getElementById("name"); var name=escape(nameObj.value); nameObj.disabled=true;
  var emailObj=document.getElementById("email"); var email=escape(emailObj.value); emailObj.disabled=true;
  var phoneObj=document.getElementById("phone"); var phone=escape(phoneObj.value); phoneObj.disabled=true;
  var numObj=document.getElementById("num"); var num=numObj.value; numObj.disabled=true;
  var concert=document.getElementById("concert").innerHTML;
  var contactObj=document.getElementById("contact"); var contact=contactObj.checked?"1":"0"; contactObj.disabled=true;
  var ip=document.getElementById("ip").innerHTML;
  document.getElementById("okDone").disabled=true;
  var statusObj=document.getElementById("resStatus");
  statusObj.innerHTML="Saving Your Spot...";
  var url=handleUrl("name", name, "email", email, "phone", phone, "num", num, "ip", ip, "contact", contact, "concert", concert, "mode", "reserve");
  handleXmlRequest("reserve", url);}

function update(){
  working();
  var nameObj=document.getElementById("name"); var name=escape(nameObj.value); nameObj.disabled=true;
  var email=escape(document.getElementById("email").innerHTML);
  var phone=escape(document.getElementById("phone").innerHTML);
  var numObj=document.getElementById("num"); var num=numObj.value; numObj.disabled=true;
  var concert=document.getElementById("concert").innerHTML;
  var contactObj=document.getElementById("contact"); var contact=contactObj.checked?"1":"0"; contactObj.disabled=true;
  var ip=document.getElementById("ip").innerHTML;
  document.getElementById("okUpdate").disabled=true;
  var statusObj=document.getElementById("resStatus");
  statusObj.innerHTML="Updating Your Reservation...";
  var url=handleUrl("name", name, "email", email, "phone", phone, "num", num, "ip", ip, "contact", contact, "concert", concert, "mode", "update");
  handleXmlRequest("update", url);}

function setContact(obj){
  var stat=obj.checked;
  if(stat) {obj.nextSibling.innerHTML=" Yes"; return;}
  obj.nextSibling.innerHTML=" No"; return;}

function goView(obj){
  if(obj.nodeType=="3") obj=obj.previousSibling;
  if(obj.value=="") {document.getElementById("err").innerHTML="Error: Please enter the password"; return;}
  working();
  var url=handleUrl("mode", "view", "value", hex_md5(obj.value));
  handleXmlRequest("view", url);}

function goRefresh(){
  working();
  var url=handleUrl("mode", "refresh");
  handleXmlRequest("view", url);}

function goSort(obj){
  working();
  var sort=obj.id.substring(3);
  var dir=obj.innerHTML.substring(obj.innerHTML.length-1);
  dir=(dir=="v")?" DESC":" ASC";
  var url=handleUrl("mode", "sort", "sort", sort+dir);
  handleXmlRequest("view", url);}

function checkEnter(e){
  var key = window.event ? e.keyCode : e.which;
  alert(key);
  
  return(true);}

function working(){
  var workObj=document.getElementById("working");
  var currentOffset = document.documentElement.scrollTop || document.body.scrollTop;
  workObj.style.top=currentOffset+'px';
  var workVis=workObj.style.display;
  if(workVis==""){workObj.style.display="none"; return; }
    workObj.style.display="";}


function handleUrl(){
  var retStr="/ajax.php?sid="+Math.random();
  for(var i=0; i<arguments.length; i+=2){retStr+="&"+arguments[i]+"="+arguments[i+1];}
  return(retStr);}

function GetXmlHttpObject(){
  var xmlHttp=null;
  try{ xmlHttp=new XMLHttpRequest();}
  catch (e){
    try{ xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");}
    catch (e){ xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");}}
  return xmlHttp;}

function handleXmlRequest(mode, url){
  var xmlHttp=GetXmlHttpObject();
  if(xmlHttp==null){ alert ("Browser does not support HTTP Request"); return;}
  xmlHttp.onreadystatechange=function() { stateChanged(xmlHttp, mode);}
  xmlHttp.open("GET", url, true);
  xmlHttp.send(null);}

function stateChanged(xmlHttp, mode) { 
  var notice="<br />* Please bring your Confirmation Number with you to the concert to verify your reservation."
  if (xmlHttp.readyState==4 || xmlHttp.readyState=="complete"){
    var temp=xmlHttp.responseText;
    if(temp.indexOf("Error")!=-1){
      var errObj=document.getElementById("resStatus") || document.getElementById("err"); errObj.innerHTML=temp; return;}
    switch(mode){
      case "reserve":
        document.getElementById("resStatus").innerHTML="Confirmation Number: "+temp+notice; break;
      case "update":
        document.getElementById("resStatus").innerHTML="Updated Confirmation Number: "+temp+notice; break;
      case "test":
        var temp=temp.split("*"); var tempName=temp[0]=="email"?"Email Address":"Phone Number";
        var errObj=document.getElementById(temp[0]).parentNode.nextSibling;
        if(errObj.nodeType==3) errObj=errObj.nextSibling;
        errObj.innerHTML=temp[1]=="0"?"OK":"* That "+tempName+" has already been used.";
        errObj.style.color=(temp[1]=="0"?"#093":"#D00");
        document.getElementById("okDone").disabled=!checkReady();
        break;
      case "view":
        document.getElementById("place").innerHTML=temp;
      
        break;
      
    
    
    }
    Behaviour.apply(myrules);
    working();}}

